package BayportPractice.Assessment;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxBinary;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;

public class NewTest {
	WebDriver driver;
	// public final By
	// login=By.xpath("/html/body/div[2]/header/nav/div/div/div[2]/nav/ul/li[4]/a");
	public static final By login = By.partialLinkText("LOGI");
	public static final By username = By.name("email");
	public static final By Password = By.name("password");
	public static final By submit = By.xpath("//button[text()='Log in']");

	@BeforeMethod
	public void beforeMethod() {
		driver = new FirefoxDriver();
		driver.get("https://www.pnet.co.za/");
		String url = driver.getCurrentUrl();
		System.out.println(url);
		String Title = driver.getTitle();
		System.out.println(Title);
	}

	@Test(priority = 1)
	public void f() {
		try {

			WebElement log = driver.findElement(login);
			log.click();
			System.out.println("click the login link" + log.getText());
		} catch (Throwable e) {
			System.out.println("Click the login link" + e.getMessage());
		}

		try {
			WebElement uname = driver.findElement(username);
			uname.sendKeys("hemasis26@gmail.com");
			;
			System.out.println("ENter the Correct Usaername" + uname.getText());

		} catch (Throwable e) {
			System.out.println("enter the correct User name" + e.getMessage());
		}
		try {
			WebElement pass = driver.findElement(Password);
			pass.sendKeys("sdbcunjd");
			System.out.println("Enter the Incorrect Password" + pass.getText());
		} catch (Throwable e) {
			System.out.println("Entering the incorrect password" + e.getMessage());
		}

		try {
			WebElement sub = driver.findElement(submit);
			sub.click();
			System.out.println("login fail" + sub.getText());
			String value = driver.getTitle();
			System.out.println(value);
			
			Assert.assertEquals(value, sub);

		} catch (Throwable e) {
			System.out.println("login fail" + e.getMessage());
		}

	}

	@Test(priority = 2)
	public void f2() {
		try {

			WebElement log = driver.findElement(login);
			log.click();
			System.out.println("click the login link" + log.getText());
		} catch (Throwable e) {
			System.out.println("Click the login link" + e.getMessage());
		}

		try {
			WebElement uname = driver.findElement(username);
			uname.sendKeys("hemas26@gmail.com");
			;
			System.out.println("ENter the inCorrect Usaername" + uname.getText());

		} catch (Throwable e) {
			System.out.println("enter the correct User name" + e.getMessage());
		}
		try {
			WebElement pass = driver.findElement(Password);
			pass.sendKeys("1medical$");
			System.out.println("Enter the correct Password" + pass.getText());
		} catch (Throwable e) {
			System.out.println("Entering the correct password" + e.getMessage());
		}

		try {
			WebElement sub = driver.findElement(submit);
			sub.click();
			System.out.println("login fail" + sub.getText());
			String value = driver.getTitle();
			Assert.assertEquals(value, sub);
			System.out.println(value);

		} catch (Throwable e) {
			System.out.println("login fail" + e.getMessage());
		}

	}

	@Test(priority = 3)
	public void f3() {
		try {

			WebElement log = driver.findElement(login);
			log.click();
			System.out.println("click the login link" + log.getText());
		} catch (Throwable e) {
			System.out.println("Click the login link" + e.getMessage());
		}

		try {
			WebElement uname = driver.findElement(username);
			uname.sendKeys("hemasis26@gmail.com");
			;
			System.out.println("ENter the Correct Usaername" + uname.getText());

		} catch (Throwable e) {
			System.out.println("enter the correct User name" + e.getMessage());
		}
		try {
			WebElement pass = driver.findElement(Password);
			pass.sendKeys("1medical$");
			System.out.println("Enter the correct Password" + pass.getText());
		} catch (Throwable e) {
			System.out.println("Entering the correct password" + e.getMessage());
		}

		try {
			WebElement sub = driver.findElement(submit);
			sub.click();
			//System.out.println("login sucsess" + sub.getText());
			//String value = driver.getTitle();
			//System.out.println(value);
			String text = sub.getText();
			
			
			Assert.assertEquals(text, sub);
			

		} catch (Throwable e) {
			System.out.println("login succses" + e.getMessage());
		}

	}

	@AfterMethod
	public void afterMethod() throws InterruptedException {
		
		Thread.sleep(5000);
		driver.quit();

	}

}
