package BayportPractice.Assessment;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.FindBy;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import junit.framework.Assert;

public class Practice
{
	WebDriver driver;
	public String name="hemasis26@gmail.com";
	public String passwrd="vcahjba";
	@BeforeClass
	public void start() 
	{
		driver = new FirefoxDriver();
		driver.get("https://www.pnet.co.za/");
		String url = driver.getCurrentUrl();
		System.out.println(url);
		String Title = driver.getTitle();
		System.out.println(Title);
	}
	
	@Test
	public void operation()
	{
		
		pagefactry p=new pagefactry(driver);
		p.Clicklogin();
		p.Enteremail(name);
		p.password(passwrd);
		p.submit();
		
		
		//String actual = "Login succsess";
		  
		  //Assert.assertEquals(actual,p);
	// Assert.assertTrue(actual, true);
		 
		
	}

}
