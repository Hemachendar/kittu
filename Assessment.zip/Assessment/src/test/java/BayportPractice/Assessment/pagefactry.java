package BayportPractice.Assessment;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class pagefactry {
	 WebDriver driver;
	 
	@FindBy(partialLinkText="LOGI")WebElement login;
	@FindBy(name="email")WebElement emailid;
	@FindBy(name="password")WebElement pass;
	@FindBy(xpath = "//button[text()='Log in']")WebElement submit;
	
	
	public  pagefactry(WebDriver driver)
	{
	
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	
	public void Clicklogin()
	{
		try {
			login.click();
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void Enteremail(String name)
	{
	      emailid.sendKeys(name);
	      
	}
	
	public void password(String passwd) 
	{
		try {
			pass.sendKeys(passwd);
			System.out.println(pass.getText());
			
		} catch (Throwable e) {
			// TODO Auto-generated catch block
			System.out.println("Enter the In correct password"+e.getMessage());
		}
	}
	public void submit() 
	{
		try {
			submit.click();
			System.out.println(submit.getText());
		} catch (Throwable e) {
			// TODO Auto-generated catch block
			System.out.println("submition fail"+e.getMessage());
		}
	}
	
}
